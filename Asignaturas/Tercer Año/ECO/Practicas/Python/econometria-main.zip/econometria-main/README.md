# econometria
Scripts para asignatura Econometría
