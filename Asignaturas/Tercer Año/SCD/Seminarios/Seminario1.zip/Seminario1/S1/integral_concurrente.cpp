#include <iostream>
#include <chrono> // incluye now, time_point, duration
#include <future>
#include <vector>

using namespace std;
using namespace std::chrono;

const long m = 100000000; // El valor de m es alto (del orden de millones)
const int num_hebras = 4;

double f(double x) {
    return 4.0 / (1 + x * x); // f(x) = 4 / (1 + x^2)
}

double calcular_xj(long j) {
    return double(j + 0.5) / m;
}

double sumatoria(long inicio, long fin) {
    double suma = 0.0;
    for (long j = inicio; j < fin; ++j) {
        const double xj = calcular_xj(j); // Calcular xj
        suma += f(xj); // Añadir f(xj) a la suma
    }
    return suma;
}

// Calcula la integral de forma paralela y devuelve el resultado
double calcular_integral_future() {
    vector<future<double>> futuros;
    long bloque = m / num_hebras; //dividimos el trabajo en bloques

    for (int i = 0; i < num_hebras; ++i) {
        long inicio = i * bloque; //calculamos el inicio, mediante i que es trozo del tramo donde estamos
        long fin = (i == num_hebras - 1) ? m : inicio + bloque; // si i es el num de hebras -1, entonces fin es m, sino es el inicio + bloque
        futuros.push_back(async(launch::async, sumatoria, inicio, fin)); // usamos async para lanzar la hebra
    }

    double suma = 0.0;
    for (auto& futuro : futuros) {
        suma += futuro.get(); // acumulamos los resultados con get
    }

    return suma / m; // Devolver el valor promedio de f
}

int main() {
    // Calcula la integral secuencial y muestra el resultado
    time_point<steady_clock> instante_inicio = steady_clock::now();
    double resultado = calcular_integral_future();
    time_point<steady_clock> instante_final = steady_clock::now();

    duration<float, micro> duracion_micros = instante_final - instante_inicio;

    cout << "Resultado de la integral paralela: " << resultado << endl;
    cout << "La actividad ha tardado : " << duracion_micros.count() << " microsegundos." << endl;

    return 0;
}