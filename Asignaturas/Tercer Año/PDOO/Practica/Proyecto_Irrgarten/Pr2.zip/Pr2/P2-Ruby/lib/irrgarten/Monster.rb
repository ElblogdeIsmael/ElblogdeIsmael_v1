#encoding:utf-8

# Módulo principal del juego Irrgarten, que contiene las clases de monstruos, jugadores y otros elementos.
module Irrgarten
    # Representa un monstruo en el juego con atributos de salud, posición, fuerza e inteligencia.
    class Monster
        # Salud inicial de un monstruo.
        INITIAL_HEALTH = 5

        # @!attribute [rw] name
        #   @return [String] El nombre del monstruo.
        attr_accessor :name

        # @!attribute [rw] intelligence
        #   @return [Integer] La inteligencia del monstruo.
        attr_accessor :intelligence

        # @!attribute [rw] strength
        #   @return [Integer] La fuerza del monstruo.
        attr_accessor :strength

        # @!attribute [rw] health
        #   @return [Integer] La salud actual del monstruo.
        attr_accessor :health

        # @!attribute [rw] row
        #   @return [Integer] La fila de la posición actual del monstruo.
        attr_accessor :row

        # @!attribute [rw] col
        #   @return [Integer] La columna de la posición actual del monstruo.
        attr_accessor :col

        # Inicializa un nuevo monstruo con los atributos de nombre, inteligencia, fuerza, salud y posición.
        #
        # @param name [String] El nombre del monstruo.
        # @param intelligence [Integer] La inteligencia del monstruo.
        # @param strength [Integer] La fuerza del monstruo.
        def initialize(name, intelligence, strength)
            @name = name
            @intelligence = intelligence
            @strength = strength
            @health = INITIAL_HEALTH
            @row = -1
            @col = -1
        end

        # Verifica si el monstruo está muerto (salud <= 0).
        #
        # @return [Boolean] `true` si la salud es 0 o menor, `false` en caso contrario.
        def dead 
            return @health <= 0
        end

        # Realiza un ataque utilizando la fuerza del monstruo.
        #
        # @return [Integer] La intensidad del ataque del monstruo.
        def attack 
            return Dice.intensity(@strength)
        end

        # Establece la posición del monstruo en una fila y columna específicas.
        #
        # @param row [Integer] La fila de la nueva posición.
        # @param col [Integer] La columna de la nueva posición.
        # @return [void]
        def setPos(row, col)
            @row = row
            @col = col
        end

        # Convierte el estado del monstruo en un string para representación.
        #
        # @return [String] La representación del monstruo en formato `M[nombre, inteligencia, fuerza, salud, fila, columna]`.
        def toString
            return "Monster[#{@name}, #{@intelligence}, #{@strength}, #{@health}, #{@row}, #{@col}]"
        end

        # Reduce la salud del monstruo en 1 punto, indicando que ha sido herido.
        #
        # @return [void]
        def gotWounded 
            @health -= 1
        end

        # # Gestiona la defensa del monstruo (detalles en prácticas futuras).
        # #
        # # @return [boolean]
        # def defend(float receivedAttack)
        #     # Implementación pendiente info en la siguiente práctica
        # end

        def get_pos_x
            return @row
        end
        def get_pos_y
            return @col
        end
    end
end
