#encoding:utf-8

# Módulo principal del juego Irrgarten, que contiene las clases de jugadores, monstruos y el laberinto.
module Irrgarten 
    # Representa el juego, manejando el estado actual, los jugadores, monstruos y el laberinto.
    class Game
        # Número máximo de rondas en el juego.
        MAX_ROUNDS = 10

        # @!attribute [rw] currentPlayerIndex
        #   @return [Integer] Índice del jugador actual en la lista de jugadores.
        attr_accessor :currentPlayerIndex

        # @!attribute [rw] log
        #   @return [Array<String>] Registro de eventos ocurridos durante el juego.
        attr_accessor :log

        # @!attribute [rw] players
        #   @return [Array<Player>] Lista de jugadores en el juego.
        attr_accessor :players

        # @!attribute [rw] currentPlayer
        #   @return [Player] El jugador que actualmente tiene el turno.
        attr_accessor :currentPlayer

        # @!attribute [rw] monsters
        #   @return [Array<Monster>] Lista de monstruos en el juego.
        attr_accessor :monsters

        # @!attribute [rw] lab
        #   @return [Labyrinth] El laberinto en el que se juega.
        attr_accessor :lab 

        # Inicializa una nueva instancia del juego con los jugadores, monstruos y el laberinto configurados.
        #
        # @param nPlayers [Integer] Número de jugadores en el juego.
        def initialize(nPlayers)
            @currentPlayerIndex = Dice.whoStarts(nPlayers)
            @log = []
            
            @players = new Player[nPlayers]
            nPlayers.times do |i|
                @players[i]= new Player(i,Dice.randomIntelligence, Dice.randomStrength)
            end

            @currentPlayer = @players[@currentPlayerIndex]

            configureLabyrinth()

            lab.spreadPlayers(players)
        end

        # Verifica si el juego ha terminado.
        #
        # @return [Boolean] `true` si el juego ha finalizado, `false` en caso contrario.
        def finished
            return lab.haveAWinner
        end

        # Obtiene el estado actual del juego.
        #
        # @return [GameState] Una nueva instancia de GameState que representa el estado actual del juego.
        def getGameState
            return new GameState(lab.toString, players.toString,currentPlayerIndex,finished,log)
        end

        # Configura el laberinto añadiendo bloques y colocando monstruos.
        #
        # @return [void]
        def configureLabyrinth 
            #creamos el laberinto
            @lab = new Labyrinth(5)

            #añiadimos 5 bloques por ejemplo
            5.times do
                startRow = Dice.randomPos(lab.getRows)
                startCol = Dice.randomPos(lab.getCols)
                lenght = Dice.randomPos(5) #debo de sumarle 1?
                orientation = Dice.randomPos(2) == 0 ? Orientation.HORIZONTAL : Orientation.VERTICAL
                lab.addBlock(orientation, startRow, startCol, lenght)
            end
            #creamos los monstruos
            monsters = new Monster[3];
            monsters[0] = new Monster("Goblin", 1, 1);
            monsters[1] = new Monster("Orc", 2, 2);
            monsters[2] = new Monster("Troll", 3, 3);

            #añadimos los monstruos
            monsters.each do |monster|
                pos = lab.randomEmptyPos()
                lab.addMonster(pos[0], pos[1], monster)
            end
        end

        # Cambia el turno al siguiente jugador.
        #
        # @return [void]
        def nextPlayer
            currentPlayerIndex = (currentPlayerIndex + 1) % players.length
            currentPlayer = players[currentPlayerIndex]
        end

        # Registra que el jugador actual ganó el combate en el registro de eventos.
        #
        # @return [void]
        def logPlayerWon
            @log ||= ""  # Inicializa @log si no está definido
            @log += "Player " + currentPlayer.getNumber.to_s + " won the combat.\n"
        end

        # Registra que el monstruo ganó el combate contra el jugador actual en el registro de eventos.
        #
        # @return [void]
        def logMonsterWon
            @log ||= ""  # Inicializa @log si no está definido
            @log += "Monster won the combat against player" + currentPlayer.getNumber.to_s + ".\n"
        end

        # Registra en el log que el jugador actual ha sido resucitado.
        #
        # @return [void]
        def logResurrected
            @log ||= ""  # Inicializa @log si no está definido
            @log += "Player " + currentPlayer.getNumber.to_s + " was resurrected.\n"
        end

        # Registra en el log que el jugador actual se ha saltado el turno por estar muerto.
        #
        # @return [void]
        def logPlayerSkipTurn
            @log ||= ""
            @log += "Player " + currentPlayer.getNumber.to_s + " skipped the turn because they are dead.\n"
        end

        # Registra en el log que el jugador actual no siguió las instrucciones del jugador humano.
        #
        # @return [void]
        def logPlayerNoOrders
            @log ||= ""
            @log += "Player " + currentPlayer.getNumber.to_s + " did not follow the human player's instructions.\n"
        end

        # Registra en el log que el jugador actual se movió a una celda vacía o no pudo moverse.
        #
        # @return [void]
        def logNoMonster
            @log ||= ""
            @log += "Player " + currentPlayer.getNumber.to_s + " moved to an empty cell or could not move.\n"
        end

        # Registra en el log la ronda actual y el número máximo de rondas.
        #
        # @param rounds [Integer] Número de rondas transcurridas.
        # @param max [Integer] Número máximo de rondas.
        # @return [void]
        def logRounds(rounds, max)
            @log ||= ""
            @log += "Rounds played " + rounds.to_s + " out of " + max.to_s + ".\n"
        end


        #Practica 3

        # def nextStep(preferredDirection)
        # end
        
        # def actualDirection(preferredDirection)
        # end

        # def combat(monster)
        # end

        # def manageReward(winner)
        # end

        # def manageResurrection
        # end
    end
end


