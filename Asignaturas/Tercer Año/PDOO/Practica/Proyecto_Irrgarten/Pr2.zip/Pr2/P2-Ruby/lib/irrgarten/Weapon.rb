#encoding:utf-8
module Irrgarten
    # Clase que representa un arma en el juego.
    # Un arma tiene un nivel de potencia y un número limitado de usos.
    class Weapon
        attr_accessor :power, :uses 

        # Inicializa un nuevo arma con un nivel de potencia y usos.
        #
        # @param power [Integer] Nivel de potencia del arma.
        # @param uses [Integer] Número de veces que se puede usar el arma.
        def initialize(power, uses) 
            @power = power
            @uses = uses
        end

        # Realiza un ataque con el arma si tiene usos restantes.
        # Decrementa los usos en 1 cada vez que se usa.
        #
        # @return [Integer] Potencia del arma si tiene usos restantes, 0 en caso contrario.
        def attack
            if @uses > 0
                @uses -= 1
                return @power
            else
                return 0
            end
        end

        # Convierte el arma a una representación en cadena.
        #
        # @return [String] Representación en cadena del arma, formato "W[power, uses]".
        def to_s
            "W[#@power, #@uses]"
        end

        # Verifica si el arma debe ser descartada según el número de usos restantes.
        #
        # @return [Boolean] `true` si el arma debe ser descartada, `false` en caso contrario.
        def discard
            Dice.discardElement(@uses)
        end
    end
end
