#encoding:utf-8

module Irrgarten
    module PlayerTypes
 	FUZZY = :fuzzy
	SUPER = :super
    end
end

